package com.cyberghost.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

private val Purple = Color(0xFF6950A1)
private val Page = Color(0xFFFFF7FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("cyberghost", MODE_PRIVATE)
        setContent {
            var page by remember { mutableStateOf(0) }
            MaterialTheme(colorScheme = lightColorScheme(primary = Purple, background = Page)) {
                Column(Modifier.fillMaxSize().background(Page)) {
                    Row(
                        Modifier.fillMaxWidth().background(Purple).padding(18.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("CyberGhost", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Text(if (page == 0) "Settings" else "Messages", color = Color.White)
                    }
                    if (page == 0) SettingsScreen(prefs)
                    else MessagesScreen(prefs)
                    Spacer(Modifier.weight(1f))
                    NavigationBar(containerColor = Color.White) {
                        NavigationBarItem(selected = page == 0, onClick = { page = 0 },
                            icon = { Icon(Icons.Default.Settings, null) }, label = { Text("Settings") })
                        NavigationBarItem(selected = page == 1, onClick = { page = 1 },
                            icon = { Icon(Icons.Default.Message, null) }, label = { Text("Messages") })
                    }
                }
            }
        }
    }
}

@Composable
private fun PurpleButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Button(onClick = onClick, modifier = modifier.height(56.dp),
        shape = RoundedCornerShape(32.dp), colors = ButtonDefaults.buttonColors(containerColor = Purple)) {
        Text(text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun SettingsScreen(prefs: android.content.SharedPreferences) {
    val context = LocalContext.current
    var sim1 by remember { mutableStateOf(prefs.getString("sim1", "") ?: "") }
    var sim2 by remember { mutableStateOf(prefs.getString("sim2", "") ?: "") }
    var notice by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().padding(horizontal = 26.dp, vertical = 30.dp)) {
        Text("• Enable Auto Start", fontSize = 18.sp, color = Color(0xFF49434D))
        Spacer(Modifier.height(18.dp))
        PurpleButton("Open Settings", { 
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:${context.packageName}"))
            context.startActivity(intent)
        }, Modifier.width(220.dp))
        Spacer(Modifier.height(42.dp))
        Text("• Disable Battery Optimization", fontSize = 18.sp, color = Color(0xFF49434D))
        Spacer(Modifier.height(18.dp))
        PurpleButton("Open Settings", {
            val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
            if (!pm.isIgnoringBatteryOptimizations(context.packageName)) {
                try {
                    context.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:${context.packageName}")))
                } catch (_: Exception) {
                    context.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                }
            } else notice = "Battery optimization is already disabled."
        }, Modifier.width(220.dp))
        Spacer(Modifier.height(42.dp))
        Text("SIM 1", fontSize = 17.sp, color = Color(0xFF49434D))
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(sim1, { sim1 = it }, modifier = Modifier.weight(1f),
                singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                placeholder = { Text("Phone number") })
            Spacer(Modifier.width(12.dp))
            PurpleButton("Save", { prefs.edit().putString("sim1", sim1.trim()).apply(); notice = "SIM 1 saved" },
                Modifier.width(112.dp))
        }
        Spacer(Modifier.height(28.dp))
        Text("SIM 2", fontSize = 17.sp, color = Color(0xFF49434D))
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(sim2, { sim2 = it }, modifier = Modifier.weight(1f),
                singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                placeholder = { Text("Phone number") })
            Spacer(Modifier.width(12.dp))
            PurpleButton("Save", { prefs.edit().putString("sim2", sim2.trim()).apply(); notice = "SIM 2 saved" },
                Modifier.width(112.dp))
        }
        if (notice.isNotBlank()) {
            Spacer(Modifier.height(16.dp))
            Text(notice, color = Purple)
        }
    }
}

@Composable
private fun MessagesScreen(prefs: android.content.SharedPreferences) {
    var phone by remember { mutableStateOf(prefs.getString("sim1", "") ?: "") }
    var result by remember { mutableStateOf("Enter a phone number and tap Load Latest.") }
    var loading by remember { mutableStateOf(false) }
    var rawItems by remember { mutableStateOf(listOf<String>()) }

    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("SMS Messages", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Purple)
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(phone, { phone = it }, modifier = Modifier.fillMaxWidth(),
            label = { Text("Phone number") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone))
        Spacer(Modifier.height(12.dp))
        PurpleButton(if (loading) "Loading..." else "Load Latest", {
            if (!loading && phone.isNotBlank()) {
                loading = true
                result = "Connecting..."
                fetchLatest(phone.trim()) { body, error ->
                    rawItems = if (body != null) splitMessages(body) else emptyList()
                    result = error ?: if (body != null) "Latest response received" else "No response"
                    loading = false
                }
            } else result = "Please enter a phone number."
        }, Modifier.fillMaxWidth())
        Spacer(Modifier.height(14.dp))
        Text(result, color = Purple)
        Spacer(Modifier.height(8.dp))
        LazyColumn {
            items(rawItems) { item ->
                Card(Modifier.fillMaxWidth().padding(vertical = 5.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Text(item, Modifier.padding(14.dp), color = Color(0xFF332D38), fontSize = 14.sp)
                }
            }
        }
    }
}

private fun fetchLatest(phone: String, done: (String?, String?) -> Unit) {
    thread {
        try {
            val client = OkHttpClient.Builder()
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(20, TimeUnit.SECONDS)
                .build()
            val url = "https://ivac.center/api/message/get/latest/" +
                java.net.URLEncoder.encode(phone, "UTF-8")
            val request = Request.Builder().url(url).get().build()
            client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (response.isSuccessful) {
                    Handler(Looper.getMainLooper()).post { done(body, null) }
                } else {
                    Handler(Looper.getMainLooper()).post {
                        done(null, "Server returned HTTP ${response.code}: ${body.take(300)}")
                    }
                }
            }
        } catch (e: Exception) {
            Handler(Looper.getMainLooper()).post {
                done(null, "Network error: ${e.message ?: "Unknown error"}")
            }
        }
    }
}

private fun splitMessages(body: String): List<String> = try {
    val json = body.trim()
    when {
        json.startsWith("[") -> {
            val arr = JSONArray(json)
            (0 until arr.length()).map { arr.optJSONObject(it)?.toString(2) ?: arr.opt(it).toString() }
        }
        json.startsWith("{") -> {
            val obj = JSONObject(json)
            val arr = obj.optJSONArray("messages")
            if (arr != null) (0 until arr.length()).map { arr.optJSONObject(it)?.toString(2) ?: arr.opt(it).toString() }
            else listOf(obj.toString(2))
        }
        else -> listOf(body)
    }
} catch (_: Exception) { listOf(body) }
